## Product Entity
# Entity ->>> productName, productCategory, productPrice, productUnitInStock, productDescription
# Temel crud metotlarının implement edilmesi gerekiyor. (findAll, save, delete, deleteById...) ->> Service interfacei oluşturalım. Servislere implement edelim.

# ProductRepository
# ProductService
# ProductController

#findById metodunun çalıştırılması.


