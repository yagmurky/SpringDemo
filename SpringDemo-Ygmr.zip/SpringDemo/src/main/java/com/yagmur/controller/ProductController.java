package com.yagmur.controller;

import com.yagmur.entity.Product;
import com.yagmur.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Optional;

@RestController
@RequiredArgsConstructor
@RequestMapping("/product")
public class ProductController {
    private final ProductService productService;

    @RequestMapping("/save")
    public Product save(Product product){
        return productService.save(product);
    }

    @GetMapping("/find-all")
    public List<Product> findAll(){
        return productService.findAll();
    }

    @GetMapping("/find-by-id")
    public Optional<Product> findById(Long id){
        return productService.findById(id);
    }

    @GetMapping("/update")
    public Product update(Product product){
        return productService.update(product);
    }

    /**
     * # Ürün ismine göre ürünü bulunuz.
     * # Ürün isminin içerdiği harf veya kelimeye göre ürünü bulunuz.
     * # Belirli fiyat aralığındaki ürünleri listeleyiniz.
     */

    //localhost:8080/product/find-product-by-name?productName=Samsung
    @GetMapping("/find-product-by-name")
    public Optional<Product> findProductByproductName(String productName){
        return productService.findProductByName(productName);
    }

    //localhost:8080/product/find-product-by-price-between?minPrice=9000&maxPrice=15000
    @GetMapping("/find-product-by-price-between")
    public List<Product> findAllByProductPriceBetween(Double minPrice, Double maxPrice){
        return productService.findAllByProductPriceBetween(minPrice, maxPrice);
    }

    //localhost:8080/product/find-product-by-name-containing?productName=beko
    @GetMapping("/find-product-by-name-containing")
    public List<Product> findByProductNameContainingIgnoreCase (String productName){
        return productService.findByProductNameContainingIgnoreCase(productName);
    }

    //localhost:8080/product/find-product-by-name-ignore-case?productName=beko
    @GetMapping("/find-product-by-name-ignore-case")
    public Optional<Product> findByProductNameIgnoreCase (String productName){
        return productService.findByProductNameIgnoreCase(productName);
    }

}
